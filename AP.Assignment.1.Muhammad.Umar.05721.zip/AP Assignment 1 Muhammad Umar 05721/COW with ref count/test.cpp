#include "test.h"

int main() 
{
	testShallowCopy();
	testCheckRefCountDecrease();
}