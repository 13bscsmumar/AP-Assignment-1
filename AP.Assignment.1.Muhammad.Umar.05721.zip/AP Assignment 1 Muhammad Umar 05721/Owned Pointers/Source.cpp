#include "test.h"

int main()
{
	testShallowCopy();
	testCharStarToStringBuffer();
	return 0;
}